import CoreService from './coreService';

export default CoreService;
