import { useEffect, useCallback, useRef, useState } from 'react';
import FirebaseService from 'app/services/firebaseService';

const EmailLinkAuthPage = () => {
  const [loading, setLoading] = useState(false);
  const requestExecutedRef = useRef();
  // const { state, setError } = useRequestState();
  const redirectToRegister = useCallback(() => {
    return (window.location.href = '/register');
  }, [window.location.href]);

  const [seconds, setSeconds] = useState(3);

  useEffect(() => {
    const timer = setInterval(() => {
      setLoading(true);
      if (seconds === 0) {
        return;
      }
      setSeconds(seconds - 1);
    }, 1000);
    // clearing interval
    return () => clearInterval(timer);
  });
  useEffect(() => {
    if (seconds === 0) {
      setLoading(false);
    }
  }, [seconds]);
  // in this effect, we execute the functions to log the user in
  useEffect(() => {
    if (seconds === 0) {
      // let's prevent duplicate calls (which should only happen in dev mode)
      if (requestExecutedRef.current) {
        return;
      }
      // do not run on the server
      if (!window.location.href) {
        // setError('generic');
        return;
      }
      // let's verify the auth method is email link
      // if (!FirebaseService.auth.isSignInWithEmailLink(window.location.href)) {
      //   console.log(
      //     'how can I set?',
      //     window.location.href,
      //     FirebaseService.auth.isSignInWithEmailLink(
      //       'https://cogesplus-e8a7f.firebaseapp.com/__/auth/action?mode=verifyEmail&oobCode=t9vXwrpjTvTrBfkC15xFpwTcyogp6MZiXwMv0tRAXy8AAAGF-n0-hA&apiKey=AIzaSyAPN9lu_Vp1jxV1Ih-cn-sp0qBsPvbWGms&lang=en'
      //     )
      //   );
      //   // setError('generic');
      //   return;
      // }
      const email = localStorage.getItem('mail-confirm');
      // let's get email used to get the link
      if (!email) {
        // setError('generic');
        return;
      }
      Func(email, window.location.href);
    }
  }, [FirebaseService.auth, loading, seconds, redirectToRegister]);

  const Func = (email, href) => {
    console.log('here is func');
    requestExecutedRef.current = true;
    console.log('here is func', requestExecutedRef);
    try {
      // sign in with link, and retrieve the ID Token
      // await signInWithEmailLink(auth, email, href);
      // let's clear the email from the storage
      // localStorage.removeItem('mail-confirm');
      localStorage.setItem('mailchimp', 'auth');
      // redirect user to the home page
      redirectToRegister();
    } catch (e) {
      return e;
    }
  };
  return <div>loading... {seconds}</div>;
};
export default EmailLinkAuthPage;
