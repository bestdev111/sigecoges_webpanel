const authRoles = {
  super_admin: ['super_admin'],
  admin: ['super_admin', 'admin'],
  onlyGuest: [],
};

export default authRoles;
