/* eslint-disable no-else-return */
/* eslint-disable consistent-return */
import { createSlice } from '@reduxjs/toolkit';
import firebaseService from 'app/services/firebaseService';
import { showMessage } from 'app/store/fuse/messageSlice';

export const doVerifyEmail = (email, password) => async (dispatch) => {
  if (!firebaseService.auth) {
    console.warn("Firebase Service didn't initialize, check your configuration");

    return () => false;
  }
  // should do it.
  const actionCodeSettings = {
    url: 'https://cogesplus-e8a7f.firebaseapp.com/auth-link?',
    handleCodeInApp: true,
  };
  return firebaseService.auth
    .createUserWithEmailAndPassword(email, password)
    .then(async (response) => {
      if (!response.user.emailVerified) {
        return response.user
          .sendEmailVerification()
          .then(() => {
            window.localStorage.setItem('mail-confirm', email);
            firebaseService.auth.signOut();
            window.location.href = '/mail-confirm';
          })
          .catch((error) => {
            const emailErrorCodes = ['auth/email-already-in-use', 'auth/invalid-email'];
            const response1 = [];
            if (emailErrorCodes.includes(error.code)) {
              response1.push({
                type: 'email',
                message: error.message,
              });
            }
            return dispatch(registerError(response1));
          });
        // dispatch(
        //   createUserSettingsFirebase({
        //     ...response.user,
        //     email,
        //   })
        // );
      }
    })
    .catch((error) => {
      const emailErrorCodes = ['auth/email-already-in-use', 'auth/invalid-email'];
      const passwordErrorCodes = ['auth/weak-password', 'auth/wrong-password'];
      const response = [];
      if (emailErrorCodes.includes(error.code)) {
        response.push({
          type: 'email',
          message: error.message,
        });
      }
      if (passwordErrorCodes.includes(error.code)) {
        response.push({
          type: 'password',
          message: error.message,
        });
      }
      if (error.code === 'auth/invalid-api-key') {
        dispatch(showMessage({ message: error.message }));
      }
      return dispatch(registerError(response));
    });
};

export const registerWithFirebase = (model) => async (dispatch) => {
  if (!firebaseService.auth) {
    console.warn("Firebase Service didn't initialize, check your configuration");

    return () => false;
  }
  const { email, password, phone } = model;

  firebaseService.db
    .ref('tbl_user')
    .orderByChild('phone')
    .equalTo(phone.toString())
    .on('value', async (snapshot) => {
      console.log('sssss', snapshot.val());
      if (snapshot.val() !== null) {
        const userId = Object.keys(snapshot.val());
        console.log('sssss', userId, snapshot.val());
        return firebaseService.db
          .ref(`tbl_user/${userId}`)
          .set({ email, password })
          .then((response) => {
            console.log('createUserWithEmailAndPassword', response);
            /// //////////
            response.user.sendEmailVerification({
              url: process.env.REACT_APP_CONFIRMATION_EMAIL_REDIRECT,
            });
            firebaseService.auth.signOut();
            // dispatch(
            //   createUserSettingsFirebase({
            //     ...response.user,
            //     phone,
            //     email,
            //   })
            // );
            // return dispatch(registerSuccess());
          })
          .catch((error) => {
            const emailErrorCodes = ['auth/email-already-in-use', 'auth/invalid-email'];
            const passwordErrorCodes = ['auth/weak-password', 'auth/wrong-password'];
            const response = [];
            if (emailErrorCodes.includes(error.code)) {
              response.push({
                type: 'email',
                message: error.message,
              });
            }
            if (passwordErrorCodes.includes(error.code)) {
              response.push({
                type: 'password',
                message: error.message,
              });
            }
            if (error.code === 'auth/invalid-api-key') {
              dispatch(showMessage({ message: error.message }));
            }
            return dispatch(registerError(response));
          });
      } else {
        console.log('error');
        const response = [];
        response.push({
          type: 'phone',
          message: 'This phone already in use or invalid',
        });
        return dispatch(registerError(response));
      }
    });
};

const initialState = {
  success: false,
  errors: [],
};

const registerSlice = createSlice({
  name: 'auth/register',
  initialState,
  reducers: {
    emailVerifySuccess: (state, action) => {
      state.emailVerified = true;
      state.success = false;
      state.errors = [];
    },
    emailVerifyError: (state, action) => {
      state.emailVerified = false;
      state.success = false;
      state.errors = [];
    },
    registerSuccess: (state, action) => {
      state.emailVerified = true;
      state.success = true;
      state.errors = [];
    },
    registerError: (state, action) => {
      state.emailVerified = false;
      state.success = false;
      state.errors = action.payload;
    },
  },
  extraReducers: {},
});

export const { registerSuccess, registerError, emailVerifySuccess, emailVerifyError } =
  registerSlice.actions;

export default registerSlice.reducer;
