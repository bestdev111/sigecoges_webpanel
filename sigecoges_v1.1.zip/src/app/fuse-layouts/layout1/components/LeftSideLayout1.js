import { memo } from 'react';

function LeftSideLayout1() {
  return <></>;
}

export default memo(LeftSideLayout1);
